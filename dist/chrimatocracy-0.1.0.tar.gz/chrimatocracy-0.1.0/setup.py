# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['chrimatocracy',
 'chrimatocracy.donations',
 'chrimatocracy.model',
 'chrimatocracy.network',
 'chrimatocracy.utils']

package_data = \
{'': ['*']}

install_requires = \
['igraph==0.9.11',
 'leidenalg==0.8.10',
 'matplotlib>=3.5.3,<4.0.0',
 'numpy==1.23.1',
 'pandas==1.4.3',
 'scipy>=1.9.0,<2.0.0',
 'seaborn==0.11.2',
 'statsmodels==0.13.2',
 'unicodecsv==0.14.1',
 'unidecode==1.3.4']

setup_kwargs = {
    'name': 'chrimatocracy',
    'version': '0.1.0',
    'description': 'Data Science applied to the government sector',
    'long_description': None,
    'author': 'Felipe Antunes',
    'author_email': 'felipe.antunes@me.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<3.12',
}


setup(**setup_kwargs)
